package com.upgrad.hirewheels;

import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;

@SpringBootTest
public class HireWheelsApplicationTests {

        @Test
        void contextLoads() {
        }
}
