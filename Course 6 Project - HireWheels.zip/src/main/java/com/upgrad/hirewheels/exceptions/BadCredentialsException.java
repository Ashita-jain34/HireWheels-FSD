package com.upgrad.hirewheels.exceptions;

public class BadCredentialsException extends Exception{

    public BadCredentialsException(String message){
        super(message);
    }
}
