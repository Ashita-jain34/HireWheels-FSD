package com.upgrad.hirewheels.services;

public interface InitService {
    void start();
}